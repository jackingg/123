
  #' Example data from lecture 6
  #'
  #' @author Zack almquist \email{almquist@umn.edu}
  #' @references \url{http://users.stat.umn.edu/~almquist/3811_examples/gapminder2007ex.csv}
  "d" 