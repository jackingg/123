## ------------------------------------------------------------------------
d <- read.table(url("http://www.stat.umn.edu/geyer/3701/data/q1p4.txt"),header = TRUE)
ggplot2::ggplot(d)+ggplot2::aes(x=x, y=p)+ggplot2::geom_point()
ggplot2::ggplot(d)+ggplot2::aes(x=x, y=p)+ggplot2::geom_line()
ggplot2::ggplot(d)+ggplot2::aes(x=x, y=p)+ggplot2::geom_area()

## ---- echo=FALSE, results='asis'-----------------------------------------
d <- read.table(url("http://www.stat.umn.edu/geyer/3701/data/q1p4.txt"),header = TRUE)
head(d)
data2007 <- read.csv("http://users.stat.umn.edu/~almquist/3811_examples/gapminder2007ex.csv")
tail(data2007)

