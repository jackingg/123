library(testthat)
library(JiangZhihangTools)

test_check("JiangZhihangTools")
